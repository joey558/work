启动命令
sudo docker-compose -f dokcer-stack.yml up -d
