#### 大数据高速计算引擎Spark -- 原理与源码

第五部分 Spark 原理【掌握】

第1节 Spark Runtime【重点】

第2节 Master & Worker 解析【重点】

第3节 SparkContext【掌握】

第4节 作业执行原理【重点】

第5节 Shuffle详解【重点】

第6节 内存管理【重点】

第7节 BlockManager【掌握】

第8节 数据倾斜【重点】

第9节 Spark优化【重点】

